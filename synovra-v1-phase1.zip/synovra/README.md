# Synovra — V1, Phase 1 (Auth)

Real, working auth system: register, login, logout, email verification,
forgot/reset password. Next.js (App Router) + Prisma + Postgres.

## What's real here (not simulated)
- Passwords hashed with bcrypt, never stored in plain text
- Real verification/reset codes emailed via Resend
- Real sessions via signed httpOnly JWT cookies
- Real brute-force lockout (5 failed logins → 15 min lock)
- Username availability checked live against the real database

## 1. Get your two accounts

1. **Neon** (https://neon.tech) — you said you already have this. Grab the
   **pooled connection string** from your project dashboard.
2. **Resend** (https://resend.com) — free tier, used to send real emails.
   Sign up, then go to *API Keys* → *Create API Key*. Copy it — you won't
   see it again.

## 2. Local setup (optional, to test before deploying)

```bash
cp .env.example .env
# paste your real DATABASE_URL and RESEND_API_KEY into .env
npm install
npx prisma migrate dev --name init
npm run dev
```

Visit http://localhost:3000 — it should redirect you to /login.

## 3. Push to GitHub

Unzip this project, then either drag-and-drop the folder into a new GitHub
repo via the web UI, or:

```bash
git init
git add .
git commit -m "Synovra V1 Phase 1: auth system"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

## 4. Deploy on Render

1. New → Web Service → connect your GitHub repo.
2. Build Command: `npm install && npm run build`
3. Start Command: `npm start`
4. Go to the **Environment** tab and add these (this is "where you put the
   API keys"):

   | Key | Value |
   |---|---|
   | `DATABASE_URL` | your Neon pooled connection string |
   | `RESEND_API_KEY` | your Resend API key |
   | `EMAIL_FROM` | `Synovra <onboarding@resend.dev>` (see note below) |
   | `JWT_SECRET` | any long random string (`openssl rand -base64 32`) |

5. Deploy. The first deploy runs `prisma generate` automatically
   (via `postinstall`), but you still need to run the migration once
   against your live Neon database:

   ```bash
   npx prisma migrate deploy
   ```
   (Run this locally with your `.env` pointed at the Neon URL, or via
   Render's Shell tab on the service.)

## Important limitation to know about (Resend sandbox)

Until you verify your own domain in Resend, you can only send email to the
address you signed up to Resend with, from their shared test address
`onboarding@resend.dev`. That's fine for testing solo — to let *other*
people register and receive real emails, verify a domain in Resend and set
`EMAIL_FROM` to an address on it.

## Not built yet (later phases, per the V1 plan)

- Profile system (avatar upload, edit profile, country/language, public/private)
- Nav shell (hamburger menu) + real dashboard
- AI tools, search, favorites, history, collections
- Communities, posts, notifications
- Premium + Flutterwave payments
- Admin dashboard + analytics
- i18n, final security hardening
